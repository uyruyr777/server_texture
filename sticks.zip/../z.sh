#!/bin/bash
cd sticks
zip -r sticks.zip pack.mcmeta assets ../
mv sticks.zip ../
