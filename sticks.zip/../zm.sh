#!/bin/bash
mv sticks.zip /media/uyruyr777/Локальный\ диск/.main\ mods/main/Instances/mine/
